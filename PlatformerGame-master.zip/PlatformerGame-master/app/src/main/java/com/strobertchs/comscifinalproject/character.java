package com.strobertchs.comscifinalproject;

public class character extends object{

    public character(int blockX, int blockY, int height, int width, double blockSize){
        super(blockX,blockY,height,width,blockSize);

    }
    //public abstract void health();
}

